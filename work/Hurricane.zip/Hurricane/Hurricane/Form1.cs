﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hurricane
{
    public partial class Hurricane : Form
    {
        public Hurricane()
        {
            InitializeComponent();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            //declare variables 
            int hurricaneCategory;

            hurricaneCategory = Convert.ToInt32(textBoxWindSpeed.Text);

            if (hurricaneCategory < 74)
            {
                textBoxCategory.Text = "Not a Hurricane";
            }
            else if (hurricaneCategory >= 74 && hurricaneCategory <= 95)
            {
                textBoxCategory.Text = "Category 1 Hurricane";
            }
            else if (hurricaneCategory >= 96 && hurricaneCategory <= 110)
            {
                textBoxCategory.Text = "Category 2 Hurricane";
            }
            else if (hurricaneCategory >= 111 && hurricaneCategory <= 129)
            {
                textBoxCategory.Text = "Category 3 Hurricane";
            }
            else if (hurricaneCategory >= 130 && hurricaneCategory <= 156)
            {
                textBoxCategory.Text = "Category 4 Hurricane";
            }
            else if (hurricaneCategory > 157)
            {
                textBoxCategory.Text = "Category 5 Hurricane";
            }
            
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxCategory.Text = "";
            textBoxWindSpeed.Text = "";
            textBoxWindSpeed.Focus();
        }
    }
}
