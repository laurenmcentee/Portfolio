﻿using System;
using static System.Console;

namespace HOT1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declare Variables 

            string firstName;
            string lastName;
            double hoursWorked;
            double hourlyRate;
            double grossPay;
            double totPayroll;

            string firstName2;
            string lastName2;
            double hoursWorked2;
            double hourlyRate2;
            double grossPay2;
            

            //Prompt for input
            Write("Please Enter first name for employee 1: ");
                firstName = ReadLine();
            Write("Please Enter last name for employee 1: ");
                lastName = ReadLine();
            Write("Please Enter Hours worked for employee 1: ");
                hoursWorked = Convert.ToDouble(ReadLine());
            Write("Please Enter Hourly Rate for employee 1: ");
                hourlyRate = Convert.ToDouble(ReadLine());

            WriteLine("\n");

            //Calculate Gross Pay 
            grossPay = hoursWorked * hourlyRate;

            WriteLine("First Name: " + firstName + "\n" +
                       "Last Name: " + lastName + "\n" +
                       "Hours Worked: " + hoursWorked.ToString("f2") + "\n" +
                       "Hourly Rate: " + hourlyRate.ToString("C2") + "\n" +
                       "Gross Pay: " + grossPay.ToString("C2"));

            WriteLine("\n");

            Write("Please Enter first name for employee 2: ");
            firstName2 = ReadLine();
            Write("Please Enter last name for employee 2: ");
            lastName2 = ReadLine();
            Write("Please Enter Hours worked for employee 2: ");
            hoursWorked2 = Convert.ToDouble(ReadLine());
            Write("Please Enter Hourly Rate for employee 2: ");
            hourlyRate2 = Convert.ToDouble(ReadLine());

            grossPay2 = hoursWorked2 * hourlyRate2;

            WriteLine("\n");

            WriteLine("First Name: " + firstName2 + "\n" +
                       "Last Name: " + lastName2 + "\n" +
                       "Hours Worked: " + hoursWorked2.ToString("f2") + "\n" +
                       "Hourly Rate: " + hourlyRate2.ToString("C2") + "\n" +
                       "Gross Pay: " + grossPay2.ToString("C2"));

            totPayroll = grossPay + grossPay2;

            WriteLine("\n");

            WriteLine("Total Gross Pay: " + totPayroll.ToString("C2"));

            ReadLine();


        }
    }
}
