﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InchesToCentimetersGUI
{
    public partial class InchesToCentimeters : Form
    {
        public InchesToCentimeters()
        {
            InitializeComponent();
        }

        //Declare and initialize program constant 

        const double CENTIMETERSINANINCH = 2.54;



        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxInches.Text = "";
            textBoxCentimeters.Text = "";
            textBoxInches.Focus();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Exit the program now!", 
                "EXIT PROGRAM?", 
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Information) == 
                DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            //Declare and initialize local variables
            double inches = 0.0;
            double centimeters = 0.0; 

            //Numeric value in inches text box 
            if (isNumeric(textBoxInches.Text))
            {
                inches = Convert.ToDouble(textBoxInches.Text);
                centimeters = inches * CENTIMETERSINANINCH;
                textBoxCentimeters.Text = centimeters.ToString("f2"); 
            }
            else
            {
                MessageBox.Show("Blank or Non-Numeric Input",
                                "INVALID INPUT. PLEASE RE-ENTER",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                                textBoxInches.Text = "";
                                textBoxInches.Focus();
            }

        }

        private bool isNumeric(String input)
        {
            double test;
            return double.TryParse(input, out test);
        }
    }
}
